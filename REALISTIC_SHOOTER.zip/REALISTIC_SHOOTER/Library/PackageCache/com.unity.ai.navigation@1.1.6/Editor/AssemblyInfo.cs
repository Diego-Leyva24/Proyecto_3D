using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.AI.Navigation.Editor.Tests")]
