namespace Unity.PlasticSCM.Editor.UI.StatusBar
{
    internal interface INotificationContent
    {
        void OnGUI();
    }
}
